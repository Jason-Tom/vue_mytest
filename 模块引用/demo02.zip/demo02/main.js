var Vue = require('vue');
var App = require('./app/App.vue');

new Vue({
  el: 'body',
  components: { App }
})