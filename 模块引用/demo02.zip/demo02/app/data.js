(function(module, exports){
	exports.dataR = function(){
		return {
			msg: "哈哈开怀大笑"
		}
	};
	exports.name = {
		msg: "哈哈开怀大笑 --> ni_menhao"
	};
}(module, module.exports));